package stepper.flow.execution;

public enum FlowExecutionResult {
    SUCCESS, FAILURE, WARNING
}
