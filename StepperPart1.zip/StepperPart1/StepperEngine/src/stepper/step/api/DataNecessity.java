package stepper.step.api;

public enum DataNecessity {
    NA, MANDATORY, OPTIONAL
}
