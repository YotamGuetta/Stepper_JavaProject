package stepper.step.api;

public enum StepResult {
    SUCCESS, FAILURE, WARNING
}
