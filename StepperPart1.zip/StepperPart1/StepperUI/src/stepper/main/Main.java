package stepper.main;

import stepper.main.ui.StepperUI;

public class Main {

    public static void main(String[] args) {
        
        StepperUI stepper = new StepperUI();
        stepper.RunStepper();

    }

}
